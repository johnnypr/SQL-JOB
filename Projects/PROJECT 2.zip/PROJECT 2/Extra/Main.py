from ExcelParser import *


parseSheet('compustat-data.xlsx')










