def f(x):
    x +=2
    return x


y = f(2) + 2
print(y)