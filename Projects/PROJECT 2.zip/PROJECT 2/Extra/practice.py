name = "Apple Inc GBHD"
company = "Apple"

name = name.split()

if name[0] == company:
    print(True)
else:
    print(name[0])


